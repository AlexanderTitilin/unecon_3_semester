from PySide6 import QtWidgets, QtCore, QtGui
import re
import sys
from downloader import *
from wallhaven import Wallhaven
from konachan import Konachan
from itertools import chain
import shutil


class ImageGrid(QtWidgets.QWidget):
    def __init__(self, images: list[Image], dir="imgs"):
        super().__init__()
        self.grid = QtWidgets.QGridLayout()
        self.grid.setSpacing(0)
        if len(images) == 0:
            msg = QtWidgets.QMessageBox()
            msg.setText("Ничего не нашлось")
            msg.exec()
        self.images = images
        self.dir = dir
        if isinstance(self.dir, QtCore.QUrl):
            self.dir = self.dir.toLocalFile()
        files = [i.preview[i.preview.rfind('/')+1::] for i in images]
        self.grid.setContentsMargins(0, 0, 0, 0)
        for (i, image) in enumerate(images):
            button = QtWidgets.QPushButton()
            p = image.preview[image.preview.rfind("/")+1::]
            button.setIcon(QtGui.QIcon(os.path.join(".tmp", p)))
            button.setIconSize(QtCore.QSize(250, 250))
            button.clicked.connect(self.generate_function(image.link))
            button.setStyleSheet("background-color: transparent;border:0px;")
            self.grid.addWidget(button, i//3, i % 3)
        self.container = QtWidgets.QWidget()
        self.container.setLayout(self.grid)
        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidget(self.container)
        self.scroll.setWidgetResizable(True)
        self.main = QtWidgets.QGridLayout()
        self.main.addWidget(self.scroll, 0, 0)
        self.setLayout(self.main)

    @QtCore.Slot()
    def generate_function(self, link):
        return lambda: self.message(link, self.dir)

    def message(self, link, dir):
        download_image(link, dir)
        msg = QtWidgets.QMessageBox()
        msg.setText("Успешно")
        msg.exec()



class ResolutionButtons(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.buttonsLayout = QtWidgets.QHBoxLayout(self)
        self.group = QtWidgets.QButtonGroup()
        self.group.setExclusive(False)
        self.resolutions = ["HD", "FHD", "2K", "4K"]
        self.buttons = [QtWidgets.QRadioButton()
                        for _ in range(len(self.resolutions))]
        for (i, b) in enumerate(self.buttons):
            b.setText(self.resolutions[i])
            self.group.addButton(b)
        for b in self.buttons:
            self.buttonsLayout.addWidget(b)


class App(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.baseLayout = QtWidgets.QVBoxLayout(self)
        self.controlLayout = QtWidgets.QHBoxLayout()
        self.tags = QtWidgets.QLineEdit()
        self.controlLayout.addWidget(self.tags)
        self.getButton = QtWidgets.QPushButton("получить")
        self.getButton.clicked.connect(self.get_images)
        self.chooser = QtWidgets.QComboBox()
        self.chooser.addItem("Wallhaven")
        self.chooser.addItem("Konachan")
        self.controlLayout.addWidget(self.getButton)
        self.shortcutGet = QtGui.QShortcut(QtGui.QKeySequence("Return"), self)
        self.shortcutGet.activated.connect(self.get_images)
        self.chooseButton = QtWidgets.QPushButton("выбор папки")
        self.chooseButton.clicked.connect(self.dialog)
        self.downloadButton = QtWidgets.QPushButton("скачать")
        self.downloadButton.clicked.connect(self.download)
        self.controlLayout.addWidget(self.downloadButton)
        self.count = QtWidgets.QSpinBox()
        self.controlLayout.addWidget(self.count)
        self.controlLayout.addWidget(self.chooseButton)
        self.controlLayout.addWidget(self.chooser)
        self.baseLayout.addLayout(self.controlLayout)
        self.resolutionButtons = ResolutionButtons()
        self.sparserItem = QtWidgets.QSpacerItem(
            20, 40, QtWidgets.QSizePolicy.Minimum, QtWidgets.QSizePolicy.Expanding)
        self.baseLayout.addWidget(self.resolutionButtons)
        self.baseLayout.addItem(self.sparserItem)
        self.directory = "imgs"

    @QtCore.Slot()
    def get_images(self):
        if os.path.exists(".tmp"):
            shutil.rmtree(".tmp")
        self.remove_imgs()
        downloders = {"Wallhaven": Wallhaven,
                      "Konachan": Konachan}
        tags = self.tags.text().replace(",", ' ').split()
        resolutions = self.get_resolutions()
        downloder = downloders[self.chooser.currentText()]
        try:
            links = downloder().get_imgs(tags, resolutions)
        except:
            msg = QtWidgets.QMessageBox()
            msg.setText("Сайт не доступен")
            msg.exec()
            return
        download_list_previews(links)
        try:
            self.imgs = ImageGrid(links, self.directory)
        except:
            self.imgs = ImageGrid(links)
        self.baseLayout.removeItem(self.sparserItem)
        self.baseLayout.addWidget(self.imgs)
        self.baseLayout.setSpacing(0)

    @QtCore.Slot()
    def dialog(self):
        self.directory = QtWidgets.QFileDialog().getExistingDirectoryUrl()
        try:
            self.imgs.dir = self.directory.toLocalFile()
        except:
            pass

    @QtCore.Slot()
    def download(self):
        try:
            download_list_images(
                self.imgs.images, self.imgs.dir, self.count.value())
            msg = QtWidgets.QMessageBox()
            msg.setText("Успешно")
            msg.exec()
        except:
            msg = QtWidgets.QMessageBox()
            msg.setText("Ошибка")
            msg.exec()

    def remove_imgs(self):
        try:
            for i in reversed(range(self.imgs.layout().count())):
                self.imgs.layout().itemAt(i).widget().setParent(None)
            self.imgs.setParent(None)
        except:
            pass

    def closeEvent(self, event):
        if os.path.exists(".tmp"):
            shutil.rmtree(".tmp")

    def get_resolutions(self):
        res = {"HD": ["1280x720", "1280x800", "1280x960"],
               "FHD": ["1920x1080", "1920x1200", "1920x1440"],
               "2K": ["2560x1440", "2560x1600", "2560x1920"],
               "4K": ["3840x2160", "3840x2400", "3840x2880"]}
        resolutions = [b.text()
                       for b in self.resolutionButtons.buttons if b.isChecked()]
        result = list(chain.from_iterable([res[i] for i in resolutions]))
        return result


