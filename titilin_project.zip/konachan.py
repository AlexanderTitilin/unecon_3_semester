import requests
from Image import Image


class Konachan:
    def get_imgs(self, tags, resolutions=[]):
        self.tags = "+".join(tags)
        self.url = f"https://konachan.net/post.json?limit=100&tags={self.tags}+rating:s"
        response = requests.get(self.url)
        if response.status_code != 200:
            raise Exception("Сайт не доступен")
        resolutions = [[int(i) for i in  r.split("x") ] for r in resolutions]
        if not resolutions:
            result = [Image(img["file_url"], img["preview_url"])
                  for img in response.json()]
        else:
            result = [Image(img["file_url"], img["preview_url"])
                  for img in response.json() if [img["jpeg_width"], img["jpeg_height"]] in resolutions]
        return result




