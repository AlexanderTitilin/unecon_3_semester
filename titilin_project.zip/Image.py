from dataclasses import dataclass

@dataclass
class Image:
    link:str
    preview:str
