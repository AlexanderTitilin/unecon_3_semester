import requests
import json
from Image import Image
from concurrent.futures import ThreadPoolExecutor
from itertools import chain


class Wallhaven():
    def get_imgs(self, tags, resolutions=[]):
        self.tags_str = "+".join(tags)
        self.resolutions_str = "%2C".join(resolutions)
        url = f"https://wallhaven.cc/api/v1/search?q={self.tags_str}&resolutions={self.resolutions_str}"
        response = requests.get(url)
        if response.status_code != 200:
            raise Exception("Сайт не доступен")
        images = response.json()
        k = images['meta']['last_page']
        with ThreadPoolExecutor(max_workers=16) as executor:
            result = executor.map(self.get_imgs_from_page, range(1, min(k+1,10)))
            return list(chain.from_iterable(result))

    def get_imgs_from_page(self, num):
        url = f"https://wallhaven.cc/api/v1/search?q={self.tags_str}&page={num}&resolutions={self.resolutions_str}"
        response = requests.get(url)
        if response.status_code != 200:
            raise Exception("Сайт не доступен")
        images = response.json()
        return [Image(i['path'], i['thumbs']['small'])
                for i in images['data']]


