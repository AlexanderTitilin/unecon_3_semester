# import json
import requests
import shutil
from concurrent.futures import ThreadPoolExecutor
import os
from Image import Image


def download_image(url, dir_name="imgs"):
    response = requests.get(url, stream=True)
    if not os.path.exists(dir_name):
        os.makedirs(dir_name)
    if response.status_code == 200:
        with open(os.path.join(dir_name, url[url.rfind('/')+1::]), "wb") as f:
            shutil.copyfileobj(response.raw, f)
    else:
        raise Exception("недоступно")


def download_image_preview(url):
    download_image(url,".tmp")


def download_list_images(images: list[Image], dir_name,n):
    with ThreadPoolExecutor(max_workers=4) as executor:
        executor.map(lambda img: download_image(img.link, dir_name), images[:n])


def download_list_previews(images: list[Image]):
    with ThreadPoolExecutor() as executor:
        executor.map(lambda img: download_image_preview(img.preview), images)


