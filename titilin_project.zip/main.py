from gui import *
if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    widget = App()
    widget.show()
    sys.exit(app.exec())
